#include "GCHierarchy.h"
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define MAX_INTT 1000000
#define INFTY 100000000


/**************************************************************************************/

void GCHierarchy::commonGridInitialization(PixelType width, PixelType height, int nLabels)
{
    terminateOnError( (width < 0) || (height <0) || (nLabels <0 ),"Illegal negative parameters");

    m_width       = width;
    m_height      = height;
    m_nPixels     = width*height;
    m_nLabels     = nLabels;
    m_grid_graph  = 1;
}

/**************************************************************************************/

void GCHierarchy::setParameters(int numParam, void *param)
{
	int *a; EnergyTermType *b;
	if(numParam == 1)
	{
		a = (int *) param; m_nTrees = a[0];
	}
	else if(numParam == 2)
	{
		a = (int *) param; m_nTrees = a[0];
		b = (EnergyTermType *) param; m_factor = b[1];
	}
	else
		printf("\nInvalid number of parameters, can only set number of HST and tree factor\n");
}

/**************************************************************************************/

void GCHierarchy::commonNonGridInitialization(PixelType nupixels, int num_labels)
{
    terminateOnError( (nupixels <0) || (num_labels <0 ),"Illegal negative parameters");

    m_nLabels        = num_labels;
    m_nPixels        = nupixels;
    m_grid_graph         = 0;

    m_neighbors = (LinkedBlockList *) new LinkedBlockList[nupixels];

    terminateOnError(!m_neighbors,"Not enough memory");
}

/**************************************************************************************/

void GCHierarchy::commonInitialization()
{
    m_labeling = (LabelType *) new LabelType[m_nPixels];
    terminateOnError(!m_labeling,"out of memory");
    for ( int i = 0; i < m_nPixels; i++ ) m_labeling[i] = (LabelType) 0;

		/* Default values of parameters */
		m_factor = (EnergyTermType) 3; m_nTrees = 10;
		m_performEM = false;
}

/**************************************************************************************/
/* Use this constructor only for grid graphs                                          */
GCHierarchy::GCHierarchy(PixelType width,PixelType height,LabelType nLabels,EnergyFunction *eng):MRF(width,height,nLabels,eng)
{
    commonGridInitialization(width,height,nLabels);

    commonInitialization(); 
}

/**************************************************************************************/
/* Use this constructor for general graphs                                            */
GCHierarchy::GCHierarchy(PixelType nPixels,int nLabels,EnergyFunction *eng):MRF(nPixels,nLabels,eng) 
{
    commonNonGridInitialization(nPixels, nLabels);
    
    commonInitialization(); 
}

/**************************************************************************************/

void GCHierarchy::setData(EnergyTermType* dataArray)
{
    m_datacost  = dataArray;
}


/**************************************************************************************/

void GCHierarchy::setData(DataCostFn dataFn)
{
    m_dataFnPix = dataFn;

}

/**************************************************************************************/

void GCHierarchy::setSmoothness(EnergyTermType* V)
{
    m_smoothcost = V;
		getMinMaxCost();

		m_maxLevel = int(ceil(log(double(m_maxcost+0.0001)/double(m_mincost))/log(double(m_factor))+1));
		computeHST();
		writeHST("/Users/emresefer/Desktop/recomb/out.txt");
	    readHST("/Users/emresefer/Desktop/recomb/out.txt");
		//writeHST("/afs/cs.stanford.edu/u/pawan/Project/MRF-MAP/MRF/hst/hst-denoise2.txt");
		//readHST("/afs/cs.stanford.edu/u/pawan/Project/MRF-MAP/MRF/hst/hst-stereo.txt");

		for(int i = 0; i < m_nTrees+1; i++)
			printHST(m_treeMet[i]);
}

/**************************************************************************************/

void GCHierarchy::setSmoothness(int smoothExp,CostVal smoothMax, CostVal lambda)
{
	if( smoothExp == 1 )
		terminateOnError(1,"Use Range Swap or Range Expansion");
	else
		terminateOnError(1,"Not a valid metric. Use Range Swap or Range Expansion");
}

/**************************************************************************************/

void GCHierarchy::setCues(EnergyTermType* hCue, EnergyTermType* vCue)
{

    m_horizWeights    = hCue;
    m_vertWeights     = vCue;
}


/**************************************************************************************/

void GCHierarchy::setSmoothness(SmoothCostGeneralFn cost)
{
	terminateOnError(1,"Specifying smoothness using function currently not allowed");
}

/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::dataEnergy()
{
    
    if ( m_dataType == ARRAY) 
        return(giveDataEnergyArray());
    else return(giveDataEnergyFnPix());

    return(0);
}

/**************************************************************************************/
    
GCHierarchy::EnergyType GCHierarchy::giveDataEnergyArray()
{
    EnergyType eng = (EnergyType) 0;


    for ( int i = 0; i < m_nPixels; i++ )
        eng = eng + m_datacost(i,m_labeling[i]);

    return(eng);
}

/**************************************************************************************/
    
GCHierarchy::EnergyType GCHierarchy::giveDataEnergyFnPix()
{

    EnergyType eng = (EnergyType) 0;

    for ( int i = 0; i < m_nPixels; i++ )
        eng = eng + m_dataFnPix(i,m_labeling[i]);

    return(eng);
}

/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::smoothnessEnergy()
{
    
    if ( m_grid_graph )
    {
        if ( m_smoothType != FUNCTION )
        {
            if (m_varWeights) return(giveSmoothEnergy_G_ARRAY_VW());
            else return(giveSmoothEnergy_G_ARRAY());
        }
        else return(giveSmoothEnergy_G_FnPix());
    }
    else
    {
        if ( m_smoothType != FUNCTION ) return(giveSmoothEnergy_NG_ARRAY());
        else  return(giveSmoothEnergy_NG_FnPix());
    }
    return(0);

}

/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::giveSmoothEnergy_NG_FnPix()
{

    EnergyType eng = (EnergyType) 0;
    int i;
    Neighbor *temp; 

    for ( i = 0; i < m_nPixels; i++ )
        if ( !m_neighbors[i].isEmpty() )
        {
            m_neighbors[i].setCursorFront();
            while ( m_neighbors[i].hasNext() )
            {
                temp = (Neighbor *) m_neighbors[i].next();
                if ( i < temp->to_node )
                    eng = eng + m_smoothFnPix(i,temp->to_node, m_labeling[i],m_labeling[temp->to_node]);
            }
        }
        
    return(eng);
    
}

/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::giveSmoothEnergy_NG_ARRAY()
{
    EnergyType eng = (EnergyType) 0;
    int i;
    Neighbor *temp; 

    for ( i = 0; i < m_nPixels; i++ )
        if ( !m_neighbors[i].isEmpty() )
        {
            m_neighbors[i].setCursorFront();
            while ( m_neighbors[i].hasNext() )
            {
                temp = (Neighbor *) m_neighbors[i].next();

                if ( i < temp->to_node )
                    eng = eng + m_smoothcost(m_labeling[i],m_labeling[temp->to_node])*(temp->weight);

            }
        }

    return(eng);
}

/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::giveSmoothEnergy_G_ARRAY_VW()
{

    EnergyType eng = (EnergyType) 0;
    int x,y,pix;

    
    for ( y = 0; y < m_height; y++ )
        for ( x = 1; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothcost(m_labeling[pix],m_labeling[pix-1])*m_horizWeights[pix-1];
        }

    for ( y = 1; y < m_height; y++ )
        for ( x = 0; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothcost(m_labeling[pix],m_labeling[pix-m_width])*m_vertWeights[pix-m_width];
        }

    
    return(eng);
    
}
/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::giveSmoothEnergy_G_ARRAY()
{

    EnergyType eng = (EnergyType) 0;
    int x,y,pix;


    for ( y = 0; y < m_height; y++ )
        for ( x = 1; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothcost(m_labeling[pix],m_labeling[pix-1]);
        }

    for ( y = 1; y < m_height; y++ )
        for ( x = 0; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothcost(m_labeling[pix],m_labeling[pix-m_width]);
        }

    return(eng);
    
}
/**************************************************************************************/

GCHierarchy::EnergyType GCHierarchy::giveSmoothEnergy_G_FnPix()
{

    EnergyType eng = (EnergyType) 0;
    int x,y,pix;


    for ( y = 0; y < m_height; y++ )
        for ( x = 1; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothFnPix(pix,pix-1,m_labeling[pix],m_labeling[pix-1]);
        }

    for ( y = 1; y < m_height; y++ )
        for ( x = 0; x < m_width; x++ )
        {
            pix = x+y*m_width;
            eng = eng + m_smoothFnPix(pix,pix-m_width,m_labeling[pix],m_labeling[pix-m_width]);
        }

    return(eng);
    
}


/****************************************************************************/
/* This procedure checks if an error has occured, terminates program if yes */

void GCHierarchy::terminateOnError(bool error_condition,const char *message)

{ 
   if  (error_condition) 
   {
      fprintf(stderr, "\n %s \n", message);
      exit(1);
    }
}

/****************************************************************************/

void GCHierarchy::clearAnswer()
{
    if (!m_labeling ) {printf("First initialize algorithm" );exit(0);}
    memset(m_labeling, 0, m_nPixels*sizeof(Label));
}

/**************************************************************************************/

void GCHierarchy::setNeighbors(PixelType pixel1, int pixel2, EnergyTermType weight)
{

    assert(pixel1 < m_nPixels && pixel1 >= 0 && pixel2 < m_nPixels && pixel2 >= 0);
    assert(m_grid_graph == 0);

    Neighbor *temp1 = (Neighbor *) new Neighbor;
    Neighbor *temp2 = (Neighbor *) new Neighbor;

    temp1->weight  = weight;
    temp1->to_node = pixel2;

    temp2->weight  = weight;
    temp2->to_node = pixel1;

    m_neighbors[pixel1].addFront(temp1);
    m_neighbors[pixel2].addFront(temp2);
    
}

/**************************************************************************************/

GCHierarchy::~GCHierarchy()
{
	delete [] m_labeling;
	if ( ! m_grid_graph ) delete [] m_neighbors;            
	for(int i = 0; i < m_nTrees+1; i++)
	{
		free(m_treeMet[i].nclust);
		for(int j = 0; j < m_maxLevel; j++)
			free(m_treeMet[i].clust[j]);
		free(m_treeMet[i].clust);
		for(int j = 0; j < m_treeMet[i].nlevel; j++)
			free(m_treeMet[i].length[j]);
		free(m_treeMet[i].length);
	}
	free(m_treeMet);
}

/**************************************************************************************/

double GCHierarchy::getDistortion(hst *treeMet, double *distortion, int count, double sigma)
{
	double maxDist = 0;

	for(int i = 0; i < m_nLabels; i++)
		for(int j = i+1; j < m_nLabels; j++)
		{
				distortion[i*m_nLabels+j] = distortion[j*m_nLabels+i] = (1-sigma)*distortion[i*m_nLabels+j] + 
																			sigma*getHSTDistance(i,j,treeMet[count])/double(m_smoothcost(i,j));
				if(distortion[i*m_nLabels+j] > maxDist)
					maxDist = distortion[i*m_nLabels+j];
		}
	return maxDist;
}

/**************************************************************************************/

double	GCHierarchy::getWeightedDistortion(hst treeMet, double *edgeWeight)
{
	double distortNum = 0, distortDenom = 0;
	for(int i = 0; i < m_nLabels; i++)
		for(int j = i+1; j < m_nLabels; j++)
		{
			distortNum += edgeWeight[i*m_nLabels+j]*getHSTDistance(i,j,treeMet);
			distortDenom += edgeWeight[i*m_nLabels+j]*double(m_smoothcost(i,j));
		}
	return(distortNum/distortDenom);
}

/**************************************************************************************/

double	GCHierarchy::getHSTDistance(int label1, int label2, hst treeMet)
{
	double dist = 0;
	int	i, j, start = 0;
	for(i = 0; i < treeMet.nlevel; i++)
	{
		if(treeMet.clust[i][label1] != treeMet.clust[i][label2])
			break;
	}
	if(!i) dist = double(treeMet.rootlength);
	else i=i-1;
	for(j = 0; j < i; j++)
		start += treeMet.nclust[j];

	for(j = i; j < treeMet.nlevel-1; j++)
	{
		dist += double(treeMet.length[j][treeMet.clust[j][label1]-start])/2.0;
		dist += double(treeMet.length[j][treeMet.clust[j][label2]-start])/2.0;
		start += treeMet.nclust[j];
	}

	return dist;
}

/**************************************************************************************/

void	GCHierarchy::readHST(char *hstFile)
{
	FILE	*fp = fopen(hstFile,"r");
	m_treeMet = (hst *) calloc(m_nTrees+1, sizeof(hst));
	for(int tnum = 0; tnum < m_nTrees+1; tnum++)
	{
		hst treeMet; 
		fscanf(fp,"%d",&treeMet.nlevel);
		fscanf(fp,"%d",&treeMet.rootlength);
		treeMet.nclust = (int *) calloc(m_maxLevel, sizeof(int));
		treeMet.clust = (int **) calloc(m_maxLevel, sizeof(int *));
		treeMet.length = (EnergyTermType **) calloc(m_maxLevel, sizeof(EnergyTermType *));
		for(int i = 0; i < treeMet.nlevel; i++)
		{
			fscanf(fp,"%d",&treeMet.nclust[i]);
			treeMet.clust[i] = (int *) calloc(m_nLabels, sizeof(int));
			for(int j = 0; j < m_nLabels; j++)
			{
				fscanf(fp,"%d",&treeMet.clust[i][j]);
			}
			treeMet.length[i] = (EnergyTermType *) calloc(treeMet.nclust[i],sizeof(EnergyTermType));
			for(int j = 0; j < treeMet.nclust[i]; j++)
				fscanf(fp,"%d",&treeMet.length[i][j]);
		}
		m_treeMet[tnum] = treeMet;
	}
	fclose(fp);
}

/**************************************************************************************/

void	GCHierarchy::writeHST(char *hstFile)
{
	FILE	*fp = fopen(hstFile,"w");
	for(int tnum = 0; tnum < m_nTrees+1; tnum++)
	{
		hst treeMet = m_treeMet[tnum];
		fprintf(fp,"%d\n",treeMet.nlevel);
		fprintf(fp,"%d\n",treeMet.rootlength);
		for(int i = 0; i < treeMet.nlevel; i++)
		{
			fprintf(fp,"%d\n",treeMet.nclust[i]);
			for(int j = 0; j < m_nLabels; j++)
				fprintf(fp,"%d ",treeMet.clust[i][j]);
			fprintf(fp,"\n");
			for(int j = 0; j < treeMet.nclust[i]; j++)
				fprintf(fp,"%d ",treeMet.length[i][j]);
			fprintf(fp,"\n");
		}
	}
	fclose(fp);
}

/**************************************************************************************/

void	GCHierarchy::printHST(GCHierarchy::hst treeMet)
{
	printf("**********************\n");
	for(int j = 0; j < m_nLabels; j++)
		printf("0 ");
	printf("\t\t\t%g\n",double(treeMet.rootlength));
	for(int i = 0; i < treeMet.nlevel; i++)
	{
		for(int j = 0; j < m_nLabels; j++)
			printf("%d ",treeMet.clust[i][j]+1);
		printf("\t\t\t");
		for(int j = 0; j < treeMet.nclust[i]; j++)
			printf("%g ",double(treeMet.length[i][j]));
		printf("\n");
	}
	printf("**********************\n\n");
}

/**************************************************************************************/

void GCHierarchy::computeHST(void)
{
	m_treeMet = (hst *) calloc(m_nTrees+1, sizeof(hst));
	srand48(time(NULL)); srand(time(NULL));
	m_treeMet[0].nclust = (int *) calloc(m_maxLevel, sizeof(int));
	m_treeMet[0].clust = (int **) calloc(m_maxLevel, sizeof(int *));
	m_treeMet[0].length = (EnergyTermType **) calloc(m_maxLevel, sizeof(EnergyTermType *));
	m_treeMet[0].nclust[0] = m_nLabels; m_treeMet[0].nlevel = 1;
	for(int i = 0; i < m_maxLevel; i++)
	{
		m_treeMet[0].clust[i] = (int *) calloc(m_nLabels, sizeof(int));
	}
	m_treeMet[0].length[0] = (EnergyTermType *) calloc(m_nLabels, sizeof(EnergyTermType));
	for(int i = 0; i < m_nLabels; i++)
	{
		m_treeMet[0].clust[0][i] = i;
	}
	m_treeMet[0].rootlength = m_maxcost;
	double lambda, alpha, sigma, rho, epsilon, maxDist;
	epsilon = 1.0; rho = m_maxcost/m_mincost;
	double *distortion = (double *) calloc(m_nLabels*m_nLabels, sizeof(double));
	maxDist = getDistortion(m_treeMet, distortion, 0, 1);
	double	*edgeWeight = new double[m_nLabels*m_nLabels];
	int count = 0;

	for(int i = 0; i < m_nLabels*m_nLabels; i++)
		edgeWeight[i] = 1.0;
	m_treeMet[1] = solveDual(edgeWeight);
	lambda = maxDist;
	alpha = 4*log(2*m_nLabels*m_nLabels/epsilon)/(lambda*epsilon);
	sigma = epsilon/(4*alpha*rho);
	maxDist = getDistortion(m_treeMet, distortion, 1, 1);
	count = 1;

	while(count < m_nTrees+1)
	{
		lambda = maxDist;
		alpha = 4*log(2*m_nLabels*m_nLabels/epsilon)/(lambda*epsilon);
		sigma = epsilon/(4*alpha*rho);
		printf("%f %f %f\n",lambda,alpha,sigma);
		while(maxDist > lambda/2)
		{
			printf("%f\n",maxDist);
			count++;
			if(count >= m_nTrees+1)
				break;
			for(int i = 0; i < m_nLabels; i++)
				for(int j = i+1; j < m_nLabels; j++)
				{
					edgeWeight[i*m_nLabels+j] = exp(alpha*distortion[i*m_nLabels+j])/double(m_smoothcost(i,j));
					edgeWeight[j*m_nLabels+i] = edgeWeight[i*m_nLabels+j];
				}
			m_treeMet[count] = solveDual(edgeWeight);
			maxDist = getDistortion(m_treeMet, distortion, count, sigma);
		}
	}

	delete [] edgeWeight;
	delete [] distortion;
}

/**************************************************************************************/

GCHierarchy::hst GCHierarchy::solveDual(double *edgeWeight)
{
	double	beta, beta_i;
	int totclust, prevTotclust, prevTotclust2;
	int	*order;
	EnergyTermType *minlength;

	int	nTrial = 200;
	double thresh = 1.0;
	hst	treeMet;
	treeMet.nclust = (int *) calloc(m_maxLevel, sizeof(int));
	treeMet.clust = (int **) calloc(m_maxLevel, sizeof(int *));
	treeMet.length = (EnergyTermType **) calloc(m_maxLevel, sizeof(EnergyTermType *));
	for(int i = 0; i < m_maxLevel; i++)
		treeMet.clust[i] = (int *) calloc(m_nLabels, sizeof(int));

	while(1)
	{
		for(int trial = 0; trial < nTrial; trial++)
		{
			/* choose random permutation of labels, random beta */
			order = randperm(m_nLabels);
			beta = pow(m_factor,drand48()); beta_i = double(m_mincost)*pow(m_factor,m_maxLevel-3)*beta;
	
			/* various inits */
			treeMet.nlevel = 0; totclust = 0; prevTotclust = 0;
			treeMet.rootlength = m_maxcost;
	
			/* cluster at levels */
			for(int i = 0; i < m_maxLevel; i++)
			{
				/* get assignments */
				getAssignments(treeMet.clust[i],beta_i,order);
	
				/* convert them to cluster numbers */
				if(i) treeMet.nclust[i] = getClusters(treeMet.clust[i],treeMet.clust[i-1],prevTotclust,totclust);
				else treeMet.nclust[i] = getInitClusters(treeMet.clust[i]);
				treeMet.nlevel++; beta_i = beta_i/m_factor;
				prevTotclust2 = prevTotclust; prevTotclust = totclust; totclust += treeMet.nclust[i];
	
				/* get edge lengths for HST */
				treeMet.length[i] = getLength(treeMet.clust[i],prevTotclust,totclust);
	
				/* terminate when all clusters are singletons */
				if(treeMet.nclust[i] == m_nLabels)
					break;
				//if(isSingleton(treeMet.clust[i],prevTotclust))
				//	break;
			}
			free(order);
			if(getWeightedDistortion(treeMet,edgeWeight) <= thresh)
			{
				return treeMet;
			}
			for(int i = 0; i < treeMet.nlevel; i++)
				free(treeMet.length[i]);
		}
		thresh += 0.05;
	}
}

/**************************************************************************************/

GCHierarchy::EnergyTermType *GCHierarchy::getLength(int *clust, int start, int end)
{
	EnergyTermType *length = (EnergyTermType *) calloc(end-start, sizeof(EnergyTermType));
	for(int i = 0; i < m_nLabels; i++)
		for(int j = 0; j < m_nLabels; j++)
		{
			if(clust[i] != clust[j])
				continue;
			if(m_smoothcost(i,j) > length[clust[i]-start])
				length[clust[i]-start] = m_smoothcost(i,j);
		}
	return length;
}

/**************************************************************************************/

int	GCHierarchy::getClusters(int *asg, int *prevClust, int start, int end)
{
	int nclust = 0;
	int **map = (int **) calloc(end-start, sizeof(int *));
	for(int i = 0; i < end-start; i++)
		map[i] = (int *) calloc(m_nLabels, sizeof(int));
	for(int i = 0; i < m_nLabels; i++)
	{
		if(!map[prevClust[i]-start][asg[i]])
		{
			nclust++; map[prevClust[i]-start][asg[i]] = end+nclust;
		}
		asg[i] = map[prevClust[i]-start][asg[i]]-1;
	}
	for(int i = 0; i < end-start; i++)
		free(map[i]);
	free(map);
	return nclust;
}

/**************************************************************************************/

int	GCHierarchy::getInitClusters(int *asg)
{
	int nclust = 0;
	int	*map = (int *) calloc(m_nLabels, sizeof(int));
	for(int i = 0; i < m_nLabels; i++)
	{
		if(!map[asg[i]])
		{
			nclust++; map[asg[i]] = nclust;
		}
		asg[i] = map[asg[i]]-1;
	}
	free(map);
	return nclust;
}

/**************************************************************************************/

bool GCHierarchy::isSingleton(int *clust, int start)
{
	int *count = (int *) calloc(m_nLabels, sizeof(int));
	for(int i = 0; i < m_nLabels; i++)
	{
		if(count[clust[i]-start])
		{
			free(count);
			return false;
		}
		count[clust[i]-start]++;
	}
	free(count);
	return true;
}

/**************************************************************************************/

void	GCHierarchy::getAssignments(int *asg, double thresh, int *order)
{
	for(int i = 0; i < m_nLabels; i++)
		for(int j = 0; j < m_nLabels; j++)
		{
			if(m_smoothcost(i,order[j]) <= thresh)
			{
				asg[i] = order[j];
				break;
			}
		}
}

/**************************************************************************************/

int	*GCHierarchy::randperm(int n)
{
	bool	*notAvail = (bool *) calloc(n, sizeof(bool));
	int *order, choice, count;
	order = (int *) calloc(n, sizeof(int));
	for(int i = 0; i < n; i++)
	{
		choice = int((n-i)*double(rand())/double(RAND_MAX+1.0));
		count = -1;
		for(int j = 0; j < n; j++)
		{
			if(!notAvail[j]) count++;
			if(count == choice)
			{
				order[i] = j;
				notAvail[j] = true;
				break;
			}
		}
	}
	free(notAvail);
	return order;
}

/**************************************************************************************/

bool	GCHierarchy::getMinMaxCost(void)
{
	double	gamma = 0, gammaMax = 0;
	bool flag = true;
	for(int i = 0; i < m_nLabels; i++)
		for(int j = 0; j < m_nLabels; j++)
		{
			if(m_smoothcost(i,j) > m_maxcost || (i == 0 && j == 1))
				m_maxcost = m_smoothcost(i,j);
			if((i != j && m_smoothcost(i,j) < m_mincost) || (i == 0 && j == 1))
				m_mincost = m_smoothcost(i,j);
			for(int k = j+1; k < m_nLabels; k++)
			{
				gamma = fabs(double(m_smoothcost(i,j)-m_smoothcost(i,k)))/double(m_smoothcost(j,k));
				if(gamma > gammaMax)
					gammaMax = gamma;
			}
		}
	printf("Gamma: %f\n",gammaMax);
	return flag;
}

/**************************************************************************************/

void HierarchyExpansion::optimizeAlg(int nIterations)
{
	hierarchyExpansion(nIterations);
}

/**************************************************************************************/

void	HierarchyExpansion::hierarchyExpansion(int nIterations)
{
  LabelType *bestLabeling = (LabelType *) new LabelType[m_nPixels];
  terminateOnError(!bestLabeling,"out of memory");
  LabelType *prevLabeling = (LabelType *) new LabelType[m_nPixels];
  terminateOnError(!prevLabeling,"out of memory");
	EnergyVal	bestE = 100000000, curE, smoothE, dataE, curE2, bestE2 = 100000000;
	double *edgeWeight = new double[m_nLabels*m_nLabels];

	int	**candidate = (int **) calloc(m_nTrees+1, sizeof(int *));
	bool	*map = (bool *) calloc(m_nTrees+1, sizeof(bool));

	for(int i = 0; i < m_nTrees+1; i++)
	{
		/* perform expansion on each HST and pick the best one*/
		HSTExpansion(m_treeMet[i],nIterations);
		curE = totalEnergy();
		if(!i || curE < bestE2)
			bestE2 = curE;

		if(m_performEM)
		{
			for(int j = 0; j < m_nPixels; j++)
				prevLabeling[j] = m_labeling[j];
			int count = 0;
			while(count < 10)
			{
				computeLabelEdgeWeight(edgeWeight,prevLabeling);
				hst treeMet = solveDual(edgeWeight);
				HSTExpansion(treeMet,nIterations);
				curE2 = totalEnergy();
				count++;
				if(curE2 >= curE)
					break;
				curE = curE2;
				for(int j = 0; j < m_nPixels; j++)
					prevLabeling[j] = m_labeling[j];
				for(int j = 0; j < m_maxLevel; j++)
				{
					free(treeMet.clust[j]); free(treeMet.length[j]);
				}
				free(treeMet.nclust); free(treeMet.clust); free(treeMet.length);
			}
			for(int j = 0; j < m_nPixels; j++)
				m_labeling[j] = prevLabeling[j];
		}
		map[i] = true;
		candidate[i] = (int *) calloc(m_nPixels, sizeof(int));
		for(int j = 0; j < m_nPixels; j++)
			candidate[i][j] = m_labeling[j];

		if(!i || curE < bestE)
		{
			for(int j = 0; j < m_nPixels; j++)
				bestLabeling[j] = m_labeling[j];
			bestE = curE;
		}
		smoothE = smoothnessEnergy(); dataE = dataEnergy();
		printf("%d (%d, %d)\n",int(curE), int(smoothE), int(dataE));
		clearAnswer();
	}
	printf("%d %d\n",int(bestE),int(bestE2));

	for(int j = 0; j < m_nPixels; j++)
		m_labeling[j] = bestLabeling[j];

	getFusedSolution_FastPD(candidate, m_nTrees+1, map, nIterations, m_labeling);

	delete [] prevLabeling;
	delete [] bestLabeling;
	delete [] edgeWeight;
	free(map);
	for(int i = 0; i < m_nTrees+1; i++)
		free(candidate[i]);
	free(candidate);
}

/**************************************************************************************/

void	HierarchyExpansion::computeLabelEdgeWeight(double *w, LabelType *l)
{
	if(m_grid_graph)
		computeLabelEdgeWeight_G(w,l);
	else
		computeLabelEdgeWeight_NG(w,l);
}

/**************************************************************************************/

void	HierarchyExpansion::computeLabelEdgeWeight_G(double *w, LabelType *l)
{
	for(int i = 0; i < m_nLabels*m_nLabels; i++)
		w[i] = 0;
	for(int i = 0; i < m_height; i++)
		for(int j = 0; j < m_width; j++)
		{
			if(j != m_width-1)
			{
				if(m_varWeights)
				{
					w[l[i*m_width+j]*m_nLabels+l[i*m_width+j+1]] += m_horizWeights[i*m_width+j];
					w[l[i*m_width+j+1]*m_nLabels+l[i*m_width+j]] += m_horizWeights[i*m_width+j];
				}
				else
				{
					w[l[i*m_width+j]*m_nLabels+l[i*m_width+j+1]]++;
					w[l[i*m_width+j+1]*m_nLabels+l[i*m_width+j]]++;
				}
			}
			
			if(i != m_height-1)
			{
				if(m_varWeights)
				{
					w[l[i*m_width+j]*m_nLabels+l[(i+1)*m_width+j]] += m_vertWeights[i*m_width+j];
					w[l[(i+1)*m_width+j]*m_nLabels+l[i*m_width+j]] += m_vertWeights[i*m_width+j];
				}
				else
				{
					w[l[i*m_width+j]*m_nLabels+l[(i+1)*m_width+j]]++;
					w[l[(i+1)*m_width+j]*m_nLabels+l[i*m_width+j]]++;
				}
			}
		}
}

/**************************************************************************************/

void	HierarchyExpansion::computeLabelEdgeWeight_NG(double *w, LabelType *l)
{
	PixelType nPix;
	EnergyTermType weight;
	Neighbor *tmp;

	for(int i = 0; i < m_nLabels*m_nLabels; i++)
		w[i] = 0;
	for(int i = 0; i < m_nPixels; i++)
	{
		if(!m_neighbors[i].isEmpty())
		{
			m_neighbors[i].setCursorFront();
			while(m_neighbors[i].hasNext())
			{
				tmp = (Neighbor *) m_neighbors[i].next();
				nPix = tmp->to_node;
				weight = tmp->weight;
				w[l[i]*m_nLabels+l[nPix]] += weight;
			}
		}
	}

}

/**************************************************************************************/

void	HierarchyExpansion::HSTExpansion(hst treeMet, int nIterations)
{
	int start = 0, end = 0;
	int	count;
	bool *map = (bool *) calloc(m_nLabels, sizeof(bool));

	if(treeMet.nlevel > 1)
	{
		for(int i = 0; i < treeMet.nlevel-2; i++)
			start += treeMet.nclust[i];
		end = start + treeMet.nclust[treeMet.nlevel-2];
	}

	LabelType	**candidate = NULL, **fusion = NULL;
	for(int level = treeMet.nlevel-2; level >= 0; level--)
	{
		candidate = (LabelType **) calloc(treeMet.nclust[level+1],sizeof(LabelType *));
		for(int i = 0; i < treeMet.nclust[level+1]; i++)
		{
			candidate[i] = (LabelType *) calloc(m_nPixels, sizeof(LabelType));
			if(level == treeMet.nlevel-2)
			{
				for(int j = 0; j < m_nPixels; j++)
					candidate[i][j] = treeMet.clust[level+1][i]-end;
			}
			else
			{
				for(int j = 0; j < m_nPixels; j++)
					candidate[i][j] = fusion[i][j];
				free(fusion[i]);
			}
		}
		if(level != treeMet.nlevel-2)
			free(fusion);

		fusion = (LabelType **) calloc(treeMet.nclust[level], sizeof(LabelType *));
		for(int i = 0; i < treeMet.nclust[level]; i++)
		{
			fusion[i] = (LabelType *) calloc(m_nPixels, sizeof(LabelType));
			for(int j = 0; j < m_nLabels; j++)
				map[j] = false;
			for(int j = 0; j < m_nLabels; j++)
			{
				if(treeMet.clust[level][j] == start+i)
				{
					map[treeMet.clust[level+1][j]-end] = true; 
				}
			}
			count = 0;
			for(int j = 0; j < m_nLabels; j++)
			{
				if(!map[j])
					continue;
				count++;
			}
			getFusedSolution_FastPD(candidate,count,map,nIterations,fusion[i]);
		}

		for(int i = 0; i < treeMet.nclust[level+1]; i++)
			free(candidate[i]);
		free(candidate);
		end = start; start -= treeMet.nclust[level-1];
	}
	
	for(int i = 0; i < treeMet.nclust[0]; i++)
		map[i] = true;
	for(int i = treeMet.nclust[0]; i < m_nLabels; i++)
		map[i] = false;

	if(treeMet.nlevel == 1)
	{
		fusion = (LabelType **) calloc(treeMet.nclust[0], sizeof(LabelType *));
		for(int i = 0; i < treeMet.nclust[0]; i++)
		{
			fusion[i] = (LabelType *) calloc(m_nPixels, sizeof(LabelType));
			for(int j = 0; j < m_nPixels; j++)
				fusion[i][j] = treeMet.clust[0][i];
		}
	}

	getFusedSolution_FastPD(fusion,treeMet.nclust[0],map,nIterations,m_labeling);

	for(int i = 0; i < treeMet.nclust[0]; i++)
		free(fusion[i]);
	free(fusion);
	free(map);
}

/**************************************************************************************/

void	HierarchyExpansion::getFusedSolution(LabelType **candidate, int nLabels, bool *map, int nIterations, LabelType *fusion)
{
	LabelType	*expLabel = (LabelType *) calloc(m_nPixels, sizeof(LabelType));

	int	initLabel;
	for(initLabel = 0; ; initLabel++)
		if(map[initLabel])
			break;
	for(int i = 0; i < m_nPixels; i++)
		fusion[i] = candidate[initLabel][i];

	bool change;
	int	count;
	for(int iter = 0; iter < nIterations; iter++)
	{
		change = false;
		count = 0;
		for(int i = 0; ; i++)
		{
			if(!map[i]) continue;
			if(m_grid_graph)
				Expand_G(fusion,candidate[i],expLabel);
			else
				Expand_NG(fusion,candidate[i],expLabel);
			for(int j = 0; j < m_nPixels; j++)
			{
				if(fusion[j] != expLabel[j])
				{
					fusion[j] = expLabel[j];
					change = true;
				}
			}
			count++;
			if(count == nLabels)
				break;
		}
		if(!change) break;
	}

	free(expLabel);
}

/**************************************************************************************/

void	HierarchyExpansion::getFusedSolution_FastPD(LabelType **candidate, int nLabels, bool *map, int nIterations, LabelType *fusion)
{
	int numpoints = m_nPixels;
	int numlabels = nLabels;
	int	numpairs, *pairs;
	int *wcosts;

	if(m_grid_graph)
	{
		numpairs = getNumPairs_G();
		pairs = getPairs_G(numpairs);
		wcosts = getWCosts_G(numpairs);
	}
	else
	{
		numpairs = getNumPairs_NG();
		pairs = getPairs_NG(numpairs);
		wcosts = getWCosts_NG(numpairs);
	}

	int	*dist = (int *) calloc(m_nLabels*m_nLabels, sizeof(int));
	for(int i = 0; i < m_nLabels; i++)
		for(int j = 0; j < m_nLabels; j++)
			dist[i*m_nLabels+j] = m_smoothcost(i,j);

	int	*lcosts = (int *) calloc(numpoints*numlabels, sizeof(int));
	int	*labelmap = (int *) calloc(numpoints*numlabels, sizeof(int));
	int	*rmap = (int *) calloc(numlabels, sizeof(int));

	int count = 0;
	for(int i = 0; ; i++)
	{
		if(!map[i])
			continue;
		rmap[count] = i;
		for(int j = 0; j < numpoints; j++)
		{
			lcosts[count*numpoints+j] = m_datacost(j,candidate[i][j]);
			labelmap[count*numpoints+j] = candidate[i][j];
		}
		count++;
		if(count >= nLabels)
			break;
	}
	if(m_grid_graph)
		reparameterize_G(lcosts, labelmap, numlabels);
	else
		reparameterize_NG(lcosts, labelmap, numlabels);

	CV_Fast_PD pd(numpoints, numlabels, m_nLabels, lcosts, labelmap, numpairs, pairs, dist, nIterations, wcosts);
	pd.run();
	for(int i = 0; i < m_nPixels; i++)
	{
		fusion[i] = candidate[rmap[pd._pinfo[i].label]][i];
	}

	free(pairs); free(wcosts);
	free(dist); free(lcosts);
	free(rmap); free(labelmap);
}

/**************************************************************************************/

void HierarchyExpansion::reparameterize_G(int *lcosts, int *labelmap, int numlabels)
{
	int pix, nPix;
	for(int i = 0; i < m_height; i++)
		for(int j = 0; j < m_width; j++)
		{
			pix = i*m_width+j;
			if(j < m_width-1)
			{
				nPix = pix+1;
				for(int k = 0; k < numlabels; k++)
				{
					if(m_varWeights)
						lcosts[k*m_nPixels+pix] += m_horizWeights[pix]*m_smoothcost(labelmap[k*m_nPixels+pix],labelmap[k*m_nPixels+nPix]);
					else
						lcosts[k*m_nPixels+pix] += m_smoothcost(labelmap[k*m_nPixels+pix],labelmap[k*m_nPixels+nPix]);
				}
			}

			if(i < m_height-1)
			{
				nPix = pix+m_width;
				for(int k = 0; k < numlabels; k++)
				{
					if(m_varWeights)
						lcosts[k*m_nPixels+pix] += m_vertWeights[pix]*m_smoothcost(labelmap[k*m_nPixels+pix],labelmap[k*m_nPixels+nPix]);
					else
						lcosts[k*m_nPixels+pix] += m_smoothcost(labelmap[k*m_nPixels+pix],labelmap[k*m_nPixels+nPix]);
				}
			}
		}
}

/**************************************************************************************/

int	HierarchyExpansion::getNumPairs_G(void)
{
	int numpairs = 2*m_height*m_width-m_height-m_width;

	return numpairs;
}

/**************************************************************************************/

int	*HierarchyExpansion::getPairs_G(int numpairs)
{
	int *pairs = (int *) calloc(2*numpairs, sizeof(int));
	int	count = 0;
	for(int i = 0; i < m_height; i++)
		for(int j = 0; j < m_width; j++)
		{
			if(j < m_width-1)
			{
				pairs[count] = i*m_width+j;
				pairs[count+1] = i*m_width+j+1;
				count = count + 2;
			}
			if(i < m_height-1)
			{
				pairs[count] = i*m_width+j;
				pairs[count+1] = (i+1)*m_width+j;
				count = count + 2;
			}
		}
	return pairs;
}

/**************************************************************************************/

int	*HierarchyExpansion::getWCosts_G(int numpairs)
{
	int	*wcosts = (int *) calloc(numpairs, sizeof(int));
	int	count = 0;
	for(int i = 0; i < m_height; i++)
		for(int j = 0; j < m_width; j++)
		{
			if(j < m_width-1)
			{
				if(m_varWeights)
					wcosts[count] = m_horizWeights[i*m_width+j];
				else
					wcosts[count] = 1;
				count = count + 1;
			}
			if(i < m_height-1)
			{
				if(m_varWeights)
					wcosts[count] = m_vertWeights[i*m_width+j];
				else
					wcosts[count] = 1;
				count = count + 1;
			}
		}
	return wcosts;
}


/**************************************************************************************/

void HierarchyExpansion::reparameterize_NG(int *lcosts, int *labelmap, int numlabels)
{
	Neighbor *tmp;
	EnergyTermType weight;
	PixelType nPix;
	for(int pix = 0; pix < m_nPixels; pix++)
	{
		if(!m_neighbors[pix].isEmpty())
		{
			m_neighbors[pix].setCursorFront();
			while(m_neighbors[pix].hasNext())
			{
				tmp = (Neighbor *) m_neighbors[pix].next();
				nPix = tmp->to_node;
				weight = tmp->weight;
				if(pix < nPix)
				{
					for(int i = 0; i < numlabels; i++)
						lcosts[i*m_nPixels+pix] += weight*m_smoothcost(labelmap[i*m_nPixels+pix],labelmap[i*m_nPixels+nPix]);
				}
			}
		}
	}
}

/**************************************************************************************/

int	HierarchyExpansion::getNumPairs_NG(void)
{
	Neighbor *tmp;
	PixelType nPix;
	int	numpairs = 0;

	for(int i = 0; i < m_nPixels; i++)
	{
		if(!m_neighbors[i].isEmpty())
		{
			m_neighbors[i].setCursorFront();
			while(m_neighbors[i].hasNext())
			{
				tmp = (Neighbor *) m_neighbors[i].next();
				nPix = tmp->to_node;
				if(i < nPix)
					numpairs++;
			}
		}
	}
	return numpairs;
}

/**************************************************************************************/

int	*HierarchyExpansion::getPairs_NG(int numpairs)
{
	Neighbor *tmp;
	PixelType nPix;
	int	*pairs = (int *) calloc(2*numpairs, sizeof(int));
	int	count = 0;

	for(int i = 0; i < m_nPixels; i++)
	{
		if(!m_neighbors[i].isEmpty())
		{
			m_neighbors[i].setCursorFront();
			while(m_neighbors[i].hasNext())
			{
				tmp = (Neighbor *) m_neighbors[i].next();
				nPix = tmp->to_node;
				if(i < nPix)
				{
					pairs[count] = i;
					pairs[count+1] = nPix;
					count += 2;
				}
			}
		}
	}
	return pairs;
}

/**************************************************************************************/

int *HierarchyExpansion::getWCosts_NG(int numpairs)
{
	Neighbor *tmp;
	EnergyTermType weight;
	PixelType nPix;
	int	*wcosts = (int *) calloc(numpairs, sizeof(int));
	int	count = 0;

	for(int i = 0; i < m_nPixels; i++)
	{
		if(!m_neighbors[i].isEmpty())
		{
			m_neighbors[i].setCursorFront();
			while(m_neighbors[i].hasNext())
			{
				tmp = (Neighbor *) m_neighbors[i].next();
				nPix = tmp->to_node;
				weight = tmp->weight;
				if(i < nPix)
				{
					wcosts[count] = weight;
					count++;
				}
			}
		}
	}
	return wcosts;
}

/**************************************************************************************/

void	HierarchyExpansion::Expand_G(LabelType *curlabel, LabelType *candidate, LabelType *newlabel)
{
	Energy *e = new Energy();
	Energy::Var *variables = (Energy::Var *) new Energy::Var[m_nPixels];
	int x,y,nPix;
	EnergyTermType weight;

	for(int i = 0; i < m_nPixels; i++)
	{
		variables[i] = e->add_variable();
		e->add_term1(variables[i],m_datacost(i,candidate[i]),m_datacost(i,curlabel[i]));
	}
	for(int i = 0; i < m_nPixels; i++)
	{
		y = i/m_width; x = i - y*m_width;
		if(x < m_width-1)
		{
			nPix = i+1;
			if(m_varWeights)
				weight = m_horizWeights[i];
			else
				weight = 1;
			e->add_term2(variables[i],variables[nPix],weight*m_smoothcost(candidate[i],candidate[nPix]),weight*m_smoothcost(candidate[i],curlabel[nPix]),
											  weight*m_smoothcost(curlabel[i],candidate[nPix]),weight*m_smoothcost(curlabel[i],curlabel[nPix]));
		}
		if(y < m_height-1)
		{
			nPix = i+m_width;
			if(m_varWeights)
				weight = m_vertWeights[i];
			else
				weight = 1;
			e->add_term2(variables[i],variables[nPix],weight*m_smoothcost(candidate[i],candidate[nPix]),weight*m_smoothcost(candidate[i],curlabel[nPix]),
											  weight*m_smoothcost(curlabel[i],candidate[nPix]),weight*m_smoothcost(curlabel[i],curlabel[nPix]));
		}
	}
	e->minimize();
	for(int i = 0; i < m_nPixels; i++)
	{
		if(e->get_var(variables[i]) == 0)
			newlabel[i] = candidate[i];
		else
			newlabel[i] = curlabel[i];
	}

	delete [] variables;
	delete e;
}

/**************************************************************************************/

void	HierarchyExpansion::Expand_NG(LabelType *curlabel, LabelType *candidate, LabelType *newlabel)
{
	Energy *e = new Energy();
	Energy::Var *variables = (Energy::Var *) new Energy::Var[m_nPixels];
	int x,y,nPix;
	EnergyTermType weight;
	Neighbor *tmp;

	for(int i = 0; i < m_nPixels; i++)
	{
		variables[i] = e->add_variable();
		e->add_term1(variables[i],m_datacost(i,candidate[i]),m_datacost(i,curlabel[i]));
	}
	for(int i = 0; i < m_nPixels; i++)
	{
		if(!m_neighbors[i].isEmpty())
		{
			m_neighbors[i].setCursorFront();
			while(m_neighbors[i].hasNext())
			{
				tmp = (Neighbor *) (m_neighbors[i].next());
				nPix = tmp->to_node;
				weight = tmp->weight;
				if(i < nPix)
				{
					e->add_term2(variables[i],variables[nPix],weight*m_smoothcost(candidate[i],candidate[nPix]),
												weight*m_smoothcost(candidate[i],curlabel[nPix]),
											  weight*m_smoothcost(curlabel[i],candidate[nPix]),
												weight*m_smoothcost(curlabel[i],curlabel[nPix]));
				}
			}
		}
	}
	e->minimize();
	for(int i = 0; i < m_nPixels; i++)
	{
		if(e->get_var(variables[i]) == 0)
			newlabel[i] = candidate[i];
		else
			newlabel[i] = curlabel[i];
	}

	delete [] variables;
	delete e;
}

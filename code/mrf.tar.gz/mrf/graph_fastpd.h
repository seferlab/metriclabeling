/* graph.h */


#ifndef __GRAPH_FASTPD_H__
#define __GRAPH_FASTPD_H__

#include "block_fastpd.h"
#include "common.h"

/*
	Nodes, arcs and pointers to nodes are
	added in blocks for memory and time efficiency.
	Below are numbers of items in blocks
*/
#define NODE_BLOCK_SIZE 512
#define ARC_BLOCK_SIZE 1024
#define NODEPTR_BLOCK_SIZE 128

/*
	special constants for node->parent
*/
#define TERMINAL ( (Graph_FastPD::arc *) 1 )		/* to terminal */
#define ORPHAN   ( (Graph_FastPD::arc *) 2 )		/* orphan */

#define INFINITE_D 1000000000		/* infinite distance to the terminal */

class Graph_FastPD
{
public:

#ifdef _MANY_LABELS_
	typedef int Label;
#else
	typedef unsigned char Label;
#endif

	typedef enum
	{
		SOURCE	= 0,
		SINK	= 1
	} termtype; /* terminals */

	/* Type of edge weights.
	   Can be changed to char, int, float, double, ... */
	typedef int Real;
	typedef Real captype;

	/* Type of total flow */
	typedef int flowtype;

	typedef void * node_id;

	/* interface functions */

	/* Destructor */
	~Graph_FastPD();

	/* Adds a node to the graph */
	void add_nodes();

	/* Adds a bidirectional edge between 'from' and 'to'
	   with the weights 'cap' and 'rev_cap' */
	void add_edges( int *pairs, int numpairs );

	/* Sets the weights of the edges 'SOURCE->i' and 'i->SINK'
	   Can be called at most once for each node before any call to 'add_tweights'.
	   Weights can be negative */
	void set_tweights(node_id i, captype cap_source, captype cap_sink);

	/* Adds new edges 'SOURCE->i' and 'i->SINK' with corresponding weights
	   Can be called multiple times for each node.
	   Weights can be negative */
	void add_tweights(node_id i, captype cap_source, captype cap_sink);

	/* After the maxflow is computed, this function returns to which
	   segment the node 'i' belongs (Graph_FastPD::SOURCE or Graph_FastPD::SINK) */
	termtype what_segment(node_id i);

	/* Computes the maxflow. Can be called only once. */
	flowtype apply_maxflow( int track_source_nodes );

/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
	
	/* internal variables and functions */

	struct arc_st;

	/* node structure */
	typedef struct node_st
	{
		arc_st			*first;		/* first outcoming arc */

		arc_st			*parent;	/* node's parent */
		node_st			*next;		/* pointer to the next active node
									   (or to itself if it is the last node in the list) */
		int				TS;			/* timestamp showing when DIST was computed */
		int				DIST;		/* distance to the terminal */
		short			is_sink;	/* flag showing whether the node is in the source or in the sink tree */

		captype			tr_cap;		/* if tr_cap > 0 then tr_cap is residual capacity of the arc SOURCE->node
									   otherwise         -tr_cap is residual capacity of the arc node->SINK */
#ifndef _METRIC_DISTANCE_
		TIME            conflict_time;
#endif
	} node;

	/* arc structure */
	typedef struct arc_st           // arc pq
	{
		node_st			*head;		/* node q, i.e. node the arc points to */
		arc_st			*next;		/* next arc with the same originating node */
		arc_st			*sister;	/* arc qp, i.e. reverse arc */

		captype			r_cap;		/* residual capacity */

		Real            cap;        // cap_{pq}   
	} arc;

	/* 'pointer to node' structure */
	typedef struct nodeptr_st
	{
		node_st			*ptr;
		nodeptr_st		*next;
	} nodeptr;

	Block<node>			*node_block;
	Block<arc>			*arc_block;
	DBlock<nodeptr>		*nodeptr_block;

	void	(*error_function)(char *);	/* this function is called if a error occurs,
										   with a corresponding error message
										   (or exit(1) is called if it's NULL) */

	flowtype			flow;		    /* total flow */

	/* Constructor. Optional argument is the pointer to the
	   function which will be called if an error occurs;
	   an error message is passed to this function. If this
	   argument is omitted, exit(1) will be called. */
	Graph_FastPD(node *nodes, arc *arcs, int num_nodes, void (*err_function)(char *) = NULL);

	void reset_flow( void )
	{
		flow = 0;
	}

	arc                *_arcs;
	node               *_nodes;
	int                 _num_nodes;

//private:

/***********************************************************************/

	node				*queue_first[2], *queue_last[2];	/* list of active nodes */
	nodeptr				*orphan_first, *orphan_last;		/* list of pointers to orphans */
	int					TIME;								/* monotonically increasing global counter */

/***********************************************************************/

	flowtype run_maxflow( int track_source_nodes );
	void setup( void );
	void do_augment(arc *middle_arc);

	/*
	Functions for processing active list.
	i->next points to the next node in the list
	(or to i, if i is the last node in the list).
	If i->next is NULL iff i is not in the list.

	There are two queues. Active nodes are added
	to the end of the second queue and read from
	the front of the first queue. If the first queue
	is empty, it is replaced by the second queue
	(and the second queue becomes empty).
	*/
	inline void set_active(node *i)
	{
		if (!i->next)
		{
			/* it's not in the list yet */
			if (queue_last[1]) queue_last[1] -> next = i;
			else               queue_first[1]        = i;
			queue_last[1] = i;
			i -> next = i;
		}
	}
	node *next_active();

	void maxflow_init();
	void augment(arc *middle_arc);
	void process_source_orphan(node *i);
	void process_sink_orphan(node *i);
};

#endif

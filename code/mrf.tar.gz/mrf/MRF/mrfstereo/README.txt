mrfstereo version 1.1

(c) Daniel Scharstein 10/22/2007

Stereo matcher front-end to MRF library

Modified to be run as part of the MRF benchmark code.  If you want a
stand-alone stereo matcher, download mrfstereo1.0.

Compile and run instructions are in the directory above.

/* GCHierarchy.h */

#ifndef __GCHIERARCHY_H__
#define __GCHIERARCHY_H__

#include "LinkedBlockList.h"
#include <assert.h>
#include "graph.h"
#include "energy.h"
#include "Fast_PD.h"
#define m_datacost(pix,lab)     (m_datacost[(pix)*m_nLabels+(lab)] )
#define m_smoothcost(lab1,lab2) (m_smoothcost[(lab1)+(lab2)*m_nLabels] )
#define USE_MEMBER_FUNCTION 0
#define PASS_AS_PARAMETER   1


class GCHierarchy:public MRF
{
public:

    ///////////////////////////////////////////////////////////////////////////////////////
    //    First define needed data types                                                 //
    ///////////////////////////////////////////////////////////////////////////////////////
    /* Type for the total energy calculation. Change it in Graph.h   */
    typedef Graph::flowtype EnergyType;

    /* Type for the individual terms in the energy function.Change it in Graph.h */
    typedef Graph::captype EnergyTermType;

    /* Type of label. Can be set to char, short, int, long */
    typedef int LabelType;

    /* Type for pixel. Can be set to  short, int, long */ 
    typedef int PixelType;

    
				
    GCHierarchy(PixelType width,PixelType height,int num_labels,EnergyFunction *eng);


    GCHierarchy(PixelType num_pixels,int nLabels, EnergyFunction *eng);

    ~GCHierarchy();

    /* Returns current label assigned to input pixel */
    inline LabelType getLabel(PixelType pixel){assert(pixel >= 0 && pixel < m_nPixels);return(m_labeling[pixel]);};

    /* Sets data cost of pixel to label */

   /* returns pointer to the answer */
    Label* getAnswerPtr(){return(m_labeling);}

    // Sets answer to zeros
    void clearAnswer();
                */
    void setNeighbors(PixelType pixel1, PixelType pixel2, EnergyTermType weight);


    /* This function can be used to change the label of any pixel at any time      */
    inline void setLabel(PixelType pixel, LabelType label){
        assert(label >= 0 && label < m_nLabels && pixel >= 0 && pixel < m_nPixels);m_labeling[pixel] = label;};
    
		void setParameters(int numParam, void *param);

    /* Returns Data Energy of current labeling */
    EnergyType dataEnergy();

    /* Returns Smooth Energy of current labeling */
    EnergyType smoothnessEnergy();

protected:
	void initializeAlg() {};

    void setData(EnergyTermType *DataCost);

	void setData(DataCostFn dataFn);

						
     void setSmoothness(EnergyTermType* V);

    void setSmoothness(int smoothExp,CostVal smoothMax, CostVal lambda);

                                                                      */
     void setCues(CostVal* hCue, CostVal* vCue); // hCue and vCue must be arrays of size width*height in row major order. 
 

     void setSmoothness(SmoothCostGeneralFn cost);


    virtual void optimizeAlg(int nIterations) = 0;

    typedef struct NeighborStruct{
        PixelType  to_node;
        EnergyTermType weight;
    } Neighbor;

		typedef struct _hst {
			int	nlevel;
			int *nclust;
			int **clust;
			EnergyTermType **length;
			EnergyTermType rootlength;
		} hst;


    LabelType *m_labeling;
    EnergyTermType *m_datacost;
    EnergyTermType *m_smoothcost;
		EnergyTermType m_mincost, m_maxcost;
    EnergyTermType *m_vertWeights;
    EnergyTermType *m_horizWeights;
    LinkedBlockList *m_neighbors;
		EnergyTermType m_factor;
		int	m_nTrees, m_maxLevel;
		bool m_performEM;
		hst *m_treeMet;

    /* Pointers to function for energy terms */
    DataCostFn m_dataFnPix;
    SmoothCostGeneralFn m_smoothFnPix;

    void commonGridInitialization( PixelType width, PixelType height, int nLabels);
    void commonNonGridInitialization(PixelType num_pixels, int num_labels);
    void commonInitialization();    

    EnergyType giveDataEnergyArray();
    EnergyType giveDataEnergyFnPix();

    EnergyType giveSmoothEnergy_G_ARRAY_VW();
    EnergyType giveSmoothEnergy_G_ARRAY();
    EnergyType giveSmoothEnergy_G_FnPix();
    EnergyType giveSmoothEnergy_NG_ARRAY();
    EnergyType giveSmoothEnergy_NG_FnPix();

    void terminateOnError(bool error_condition,const char *message);

		double getWeightedDistortion(hst treeMet, double *edgeWeight);
		double getDistortion(hst *treeMet, double *distortion, int count, double sigma);
		double getHSTDistance(int label1, int label2, hst treeMet);
		void printHST(hst treeMet);
		void readHST(char *hstFile);
		void writeHST(char *hstFile);
		void computeHST(void);
		hst solveDual(double *edgeWeight);
		EnergyTermType *getLength(int *clust, int start, int end);
		int getClusters(int *asg, int *prevClust, int start, int end);
		int getInitClusters(int *asg);
		bool isSingleton(int *clust, int start);
		void getAssignments(int *asg, double thresh, int *order);
		int *randperm(int n);
		bool getMinMaxCost(void);
};


class HierarchyExpansion: public GCHierarchy
{
public:
    HierarchyExpansion(PixelType width,PixelType height,int num_labels,EnergyFunction *eng):GCHierarchy(width,height,num_labels,eng){};
    HierarchyExpansion(PixelType nPixels, int num_labels,EnergyFunction *eng):GCHierarchy(nPixels,num_labels,eng){};

protected:
		void optimizeAlg(int nIterations);
		void hierarchyExpansion(int nIterations);
		void computeLabelEdgeWeight(double *w, LabelType *l);
		void computeLabelEdgeWeight_G(double *w, LabelType *l);
		void computeLabelEdgeWeight_NG(double *w, LabelType *l);
		void HSTExpansion(hst treeMet, int nIterations);
		void getFusedSolution(LabelType **candidate, int nLabels, bool *map, int nIterations, LabelType *fusion);
		void Expand_G(LabelType *curlabel, LabelType *candidate, LabelType *newlabel);
		void Expand_NG(LabelType *curlabel, LabelType *candidate, LabelType *newlabel);
		void getFusedSolution_FastPD(LabelType **candidate, int nLabels, bool *map, int nIterations, LabelType *fusion);
		void reparameterize_G(int *lcosts, int *labelmap, int numlabels);
		void reparameterize_NG(int *lcosts, int *labelmap, int numlabels);
		int	getNumPairs_G(void);
		int	*getPairs_G(int numpairs);
		int	*getWCosts_G(int numpairs);
		int	getNumPairs_NG(void);
		int	*getPairs_NG(int numpairs);
		int *getWCosts_NG(int numpairs);
};



#endif


import random

f= open("ml2.data", "w")
n=5500
m= 100000
labelnum= 150

f.write("param N := "+str(n)+"\n")
f.write("param M := "+str(m)+"\n")
f.write("param LabelNum := "+str(labelnum)+"\n")

f.write("param EDGES : ")
for i in range(m):
for i in range(m):
    num=random.randrange(0,2)
    
0   1   2   3   4   5   6   7   8   9  :=


f.close()
